<section id="breadcrumb">
  <ol class="breadcrumb">
    <li class="active">Dashboard/Data Lokasi</li>
  </ol>
</section>
<div class="card">
  <h3 class="card-header">Data Lokasi</h3>
  <div class="card-body">
    <a href="./?page=masuk" class="btn btn-danger"><i class="fa fa-user-plus"></i></a><br/>
    <div class="table-responsive">
      <table class="table table-striped">
        <thead class="thead-dark">
          <tr>
            <th scope="col">No</th>
            <th scope="col">Nama Lokasi</th>
            <th scope="col">Latitude</th>
            <th scope="col">Longtitude</th>
            <th scope="col">Legenda</th>
            <th scope="col">Aksi</th>
          </tr>
        </thead>
        <?php
$no = 1;
$row = $db->selectall("SELECT * FROM v_lokasi ORDER BY ? ASC", ['id']);
foreach ($row as $a) {
	?>
         <tr>
          <td><?php echo $no; ?></td>
          <td><?php echo $a['nama_lokasi']; ?></td>
          <td><?php echo $a['lat']; ?></td>
          <td><?php echo $a['lng']; ?></td>
          <td><?php echo $a['legenda']; ?></td>
          <td>
            <a href="./?page=form-view&1qazxsw2=<?php echo $a['id'] ?>"><i class="fa fa-eye" alt="Lihat Detail" title="Lihat Detail"></i></a>
            <a href="./?page=masuk&2wsxzaq1=qw&1qazxsw2=<?php echo $a['id'] ?>"><i class="fa fa-edit" alt="edit" title="edit"></i></a>
            <a onclick="return confirm('Are you sure you want to delete this item?');" href="./?page=masuk&2wsxzaq1=qa&1qazxsw2=<?php echo $a['id'] ?>"><i class="fa fa-trash" alt="delete" title="delete"></i></a>
          </td>
        </tr>
        <?php $no++;}?>
      </table>
    </div>
  </div>
</div>
