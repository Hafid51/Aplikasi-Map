
<div class="row" style="margin-top:40px;">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<div id="webgis" style="width: 100%; height: 500px"></div>
			</div>

		</div>
	</div>
</div>